require "application_system_test_case"

class StocksTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit stocks_url
  #
  #   assert_selector "h1", text: "Stock"
  # end
end
