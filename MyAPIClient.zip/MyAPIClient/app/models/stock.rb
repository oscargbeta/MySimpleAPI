class Stock
  
	def self.all
		require 'net/http'

		url = URI.parse("http://localhost:8080/api/stocks")
		req = Net::HTTP::Get.new(url.to_s)
		res = Net::HTTP.start(url.host, url.port) {|http|
		  http.request(req)
		}
			  
	    hash = JSON.parse(res.body, symbolize_names: true)
	  
	    results = {:stocks => hash}
	  		
	end

	def self.find(ticker)
		require 'net/http'
		
		url = URI.parse("http://localhost:8080/api/stocks/#{ticker}")
		req = Net::HTTP::Get.new(url.to_s)
		res = Net::HTTP.start(url.host, url.port) {|http|
		  http.request(req)
		}
			  
		hash = JSON.parse(res.body, symbolize_names: true)
	  
		results = hash
	 
	end
	
end
