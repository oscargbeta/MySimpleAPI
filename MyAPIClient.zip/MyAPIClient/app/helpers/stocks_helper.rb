module StocksHelper
end
